import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
import spacy

nlp = spacy.load('es_core_news_sm')

    
def custom_stopwords(_tokensIn):

    _tokens = _tokensIn[:]

    _toDelete = ['pos', 'yastar']

    for token in _tokensIn:
        if token in _toDelete:
            _tokens.remove(token)

    return _tokens

def tokenizar(_frase):
    
    tokens = word_tokenize(_frase, "spanish")
    
    tokens = [word.lower() for word in tokens if word.isalpha()]
    
    return tokens


def clean_sw(_tokens):
    
    clean_tokens = _tokens[:]
    for token in _tokens:
        
        if token in stopwords.words('spanish'):
            clean_tokens.remove(token)
            
    return clean_tokens

def lematizar(_tokens):
    
    lem_tokens = []
    for token in nlp(' '.join(_tokens)):
        lem_tokens.append(token.lemma_)
    return lem_tokens